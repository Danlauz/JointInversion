%% Objective function 
for i=1:100
    semilogy([0:3:300],[errSSTBM(1,i); errSSTBM(:,i)/mean(ErrInit_UHD)],'color',[0.9 0.9 0.9]);
    hold on;
end
semilogy([0:3:300],[1 mean(errSSTBM'/mean(ErrInit_UHD))],'k','LineWidth',2)
grid on

semilogy([0:3:300],[1 quantile(errSSTBM'/mean(ErrInit_UHD),0.9)],'--k','LineWidth',1.5)
grid on

semilogy([0:3:300],[1 quantile(errSSTBM'/mean(ErrInit_UHD),0.1)],'--k','LineWidth',1.5)
grid on

ylabel('Normalized objective function')
xlabel('Number of calls to the flow simulator')

ylim([0.04 2.5])

%% Table 2 Data
[t/100 mean(ErrInit_U) mean(ErrInit_UHD) mean(errSSTBM(end,:)) std(errSSTBM(end,:))]

%% Table 3 Data

ZindRef=PGS_transform(zref_C,ConstantData);
for i=1:100
    ZindSim=PGS_transform(ZSim(:,1:2,i),ConstantData);
    PCf(i)=sum(ZindRef==ZindSim)/nx/ny;
    ZindSim=PGS_transform(ZSimU_HD_C(:,:,i),ConstantData);
    PCi(i)=sum(ZindRef==ZindSim)/nx/ny;
end

KRef=log10(Permeability(zref_C,zref_K,ConstantData));
for i=1:100
    KSim=log10(Permeability(ZSim(:,1:2,i),ZSim(:,3:5,i),ConstantData));
    Kf(:,i)=corr(KRef,KSim);
    KSim=log10(Permeability(ZSimU_HD_C(:,:,i),ZSimU_HD_K(:,:,i),ConstantData));
    Ki(i)=corr(KRef,KSim);
end


[length(LocHD_C)/nx/ny/nz*100]
[mean(ErrInit_UHD) mean(errSSTBM(end,:)) std(errSSTBM(end,:))]
[ mean(PCi) mean(PCf)]
[mean(Ki) mean(Kf) ]
