function [Perm]=Permeability(zsim_C,zsim_K,ConstantData)



rock=ConstantData{5};

p1=ConstantData{8};
p2=ConstantData{9};


%%% Initialization
C1=zsim_C(:,1)<=norminv(p1);
C2=zsim_C(:,1)>norminv(p1)  & zsim_C(:,2)<=norminv(p2);
C3=zsim_C(:,1)>norminv(p1)  & zsim_C(:,2)> norminv(p2);

rock.perm=zeros(size(zsim_K(:,1)));
rock.perm(C1)=10.^(zsim_K(C1,1)+log10(0.2*darcy));  % 0.005 silty sand
rock.perm(C2)=10.^(zsim_K(C2,2)+log10(30*darcy));    % 0.5 clear sand
rock.perm(C3)=10.^(zsim_K(C3,3)+log10(150*darcy));    % 50 clear sand
Perm=rock.perm;