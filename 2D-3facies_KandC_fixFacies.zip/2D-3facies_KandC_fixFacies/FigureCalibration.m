ind=1;
switch ind
    case 1
        sim=ind;
        zsim=[zref_C zref_K];
    case 2
        sim=ind;
        zsim=ZSim(:,:,3);
    case 3
        sim=ind;
        zsim=ZSim(:,:,100);
end

%% Plurigaussian simulation  
PGS_visuel_3facies(zsim(:,1:2),nx,ny,LocHD{1, 1},ConstantData{6},x0,sim,ConstantData{8},ConstantData{9} );

%% Hydraulic conductivity field
figure(201)
imagesc(reshape(log10(rock.perm)+7,[nx,ny])');
hold on
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
colormap(jet)
colorbar()
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
set(gca,'YDir','normal')
caxis([-7.6 -1.4])

%% Drawdowm 

%Source Localisation and Index
x0Ref=[ 51 51];
LocInj=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
LocData=ConstantData{6};

[error,R_sim,states,Rt,rock,stateInit]=ObjFunc(zsim(:,1:2),zsim(:,3:5),ConstantData);

contligne=[-2 -2,-1.5 -1.5, -1 -1, -0.5,-0.5,0,0.5,0.5,1,1,2,2,3,3,4,4];
figure(100)
x = linspace(1,nx,ny);
y = linspace(1,nx,ny);
[X,Y] = meshgrid(x,y);
Z = reshape(stateInit.pressure*0.000101974,[nx,ny])';

imagesc(reshape(stateInit.pressure*0.000101974,[nx,ny])');
hold on
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
hold on
[c1,h]=contour(X,Y,Z,contligne,'--k','ShowText','on');
h.LevelList=round(h.LevelList,2);
clabel(c1,h)
colormap(jet)
colorbar()
caxis([-2 5])
set(gca,'YDir','normal')
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
%title('Reference pressure head field (m)')

for i=[1 3 6]
    figure(100+i)
    x = linspace(1,nx,ny);
    y = linspace(1,nx,ny);
    [X,Y] = meshgrid(x,y);
    Z = reshape(states{i}.pressure*0.000101974,[nx,ny])';

    imagesc(reshape(states{i}.pressure*0.000101974,[nx,ny])');
    hold on
    plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
    hold on
    plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
    hold on
    [c1,h]=contour(X,Y,Z,contligne,'--k','ShowText','on');
    h.LevelList=round(h.LevelList,2);
    clabel(c1,h)
    colormap(jet)
    colorbar()
    caxis([-2 5])
    set(gca,'YDir','normal')
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
    %title('Reference pressure head field (m)')
end