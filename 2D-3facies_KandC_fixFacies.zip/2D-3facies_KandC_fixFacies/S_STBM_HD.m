function [Z,Err,Iter,Phi]=S_STBM_HD(x0,model,c,nbsim,nl,MaxIter,OFmin,seed,ConstantData)
% Generated calibrated Gaussian random field using the sequential spectral turning band method
    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %nl -- number of lines calibrated
    %MaxIter -- maximum number of iteration for the optimizer
    %type -- Objective function to evaluate
    %OFmin -- minimum objective function value to reach
    %seed -- for reproductability
    %ConstantData -- Data needs for ObjectiveFunction.m

    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Phi  -- vector of optimized phase
    %Iter  -- Number of iteration performed
    
    % Authors : Dany Lauzon
    
%1- Spectral density computation for PGS and Gaussian conductivity fields
[F1init,sinit,rot,cx]=DensSpec1Ddl(x0,model,c);

%nbsim simuation
parfor j=1:nbsim
    %For reproductability
    rng('default')
    rng(2*j+seed);
    %Initialization
    F1=F1init; s=sinit;
    z1=cell(size(F1init,2),1);
    zsim=zeros(size(x0,1),size(F1,2)); zsimBest=zeros(size(x0,1),size(F1,2));
    err=nan(nl,1); errNow=1000;
    phi=nan(nl,size(F1,2));
    
    for k=1:size(F1,2) %Done for each covariance model.
        %3-Sampled random frequencies
        p=rand(nl,1);
        ul1=interp1(F1{k},s{k},p); % interpolate ul from p and cum       
        %4-Random vector
        z=VanCorput(nl);    % Van Corput sequence
        %5- Frequency vector
        z1{k}=z.*ul1;
    end

    %Optimization on phase U
    for i=1:nl
        %6- Calibration process on the phase U
        for k=1:size(z1,1)%Done for each covariance model.
            options=optimset('MaxIter',MaxIter,'TolX',10^-8,'Display','off');
            func = @(U) OptErr(U,k,i,zsim,c,cx,rot,z1,ConstantData);
            X=rand(1);X=[X-0.5 X+0.5];
            [U,errNew] = fminbnd(func, X(1),X(2),options);

            %7-Update
            zsim(:,k)=zsim(:,k)*sqrt((i-1)/i)+sqrt(2/i)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ 2*pi*U);
            phi(i,k)=U*2*pi;
        end

        %8-Keep the best solution
        if  errNew<=errNow && i>=1000
            errNow=errNew;
            zsimBest=zsim;
        end  

        err(i)=errNow;
        
        % check stopping criteria
        if errNow<=OFmin && i>=1000
            break;
        end
        
    end
    %9- Return Z and other parameters
    Err(:,j)=err;
    Z(:,:,j)=zsimBest;
    Phi(:,:,j)=phi;
    Iter(j)=i;
end

function [error]=OptErr(U,k,i,zsim,c,cx,rot,z1,ConstantData)

zsim(:,k)=zsim(:,k)*sqrt((i-1)/i)+sqrt(2/i)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ 2*pi*U);

lb=ConstantData{1};
ub=ConstantData{2};
LocData=ConstantData{3};

err1= max(lb(:,1)-zsim(LocData',1) ,0)+ max( zsim(LocData',1)-ub(:,1) ,0);
err2= max(lb(:,2)-zsim(LocData',2) ,0)+ max( zsim(LocData',2)-ub(:,2) ,0);

error=mean(sqrt(err1.^2+err2.^2));
