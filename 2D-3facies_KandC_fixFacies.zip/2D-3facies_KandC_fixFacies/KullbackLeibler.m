p=[sum(ZSimInd==1)/nx/ny'; sum(ZSimInd==2)/nx/ny'; sum(ZSimInd==3)/nx/ny'];
q=repmat([sum(ZrefInd==1)/nx/ny'; sum(ZrefInd==2)/nx/ny'; sum(ZrefInd==3)/nx/ny']',nbsim,1)';

KLsim=mean(sum(p.*log(p./q)))

p=[sum(ZSimUInd_HD_C==1)/nx/ny'; sum(ZSimUInd_HD_C==2)/nx/ny'; sum(ZSimUInd_HD_C==3)/nx/ny'];
q=repmat([sum(ZrefInd==1)/nx/ny'; sum(ZrefInd==2)/nx/ny'; sum(ZrefInd==3)/nx/ny']',nbsim,1)';

KLHD_U=mean(sum(p.*log(p./q)));

p=[sum(ZSimUInd_C==1)/nx/ny'; sum(ZSimUInd_C==2)/nx/ny'; sum(ZSimUInd_C==3)/nx/ny'];
q=repmat([sum(ZrefInd==1)/nx/ny'; sum(ZrefInd==2)/nx/ny'; sum(ZrefInd==3)/nx/ny']',nbsim,1)';

KL_U=mean(sum(p.*log(p./q)));

for i=1:nbsim
    corUInd(i)=corr(ZSimUInd_C(:,i),ZrefInd);
    corUHDInd(i)=corr(ZSimUInd_HD_C(:,i),ZrefInd);
    corSimInd(i)=corr(ZSimInd(:,i),ZrefInd);
end

[KL_U KLHD_U KLsim]
[mean(corUInd),mean(corUHDInd),mean(corSimInd)];

% figure(85)
% semilogy(errSSTBM/mean(ErrInit_UHD),'k'); hold on; semilogy(mean(errSSTBM'/mean(ErrInit_UHD)),'r')
% figure(86)
% semilogy(errSSTBM,'k'); hold on; semilogy(mean(errSSTBM'),'r')

[mean(ErrInit_U) mean(ErrInit_UHD)]
[ mean(errSSTBM(end,:)') std(errSSTBM(end,:)') mean(iter) std(iter) KLsim mean(corSimInd) std(corSimInd)]
%%
meanK1Sim=0;
meanK2Sim=0;
meanK3Sim=0;
stdK1Sim=0;
stdK2Sim=0;
stdK3Sim=0;
for i=1:nbsim
    meanK1Sim(i)=mean(ZSim(ZSimInd(:,i)==1,3,i));
    meanK2Sim(i)=mean(ZSim(ZSimInd(:,i)==2,4,i));
    meanK3Sim(i)=mean(ZSim(ZSimInd(:,i)==3,5,i));

    stdK1Sim(i)=std(ZSim(ZSimInd(:,i)==1,3,i));
    stdK2Sim(i)=std(ZSim(ZSimInd(:,i)==2,4,i));
    stdK3Sim(i)=std(ZSim(ZSimInd(:,i)==3,5,i));
end
[mean(meanK1Sim) mean(stdK1Sim) mean(meanK2Sim) mean(stdK2Sim) mean(meanK3Sim) mean(stdK3Sim)]

[mean(zref_K(ZrefInd==1,1)) std(zref_K(ZrefInd==1,1)) mean(zref_K(ZrefInd==2,2)) std(zref_K(ZrefInd==2,2)) mean(zref_K(ZrefInd==3,3)) std(zref_K(ZrefInd==3,3))]