function [zsimInd]=PGS_transform(zsim,ConstantData)

p1=ConstantData{8};
p2=ConstantData{9};

C1=zsim(:,1)<=norminv(p1);
C2=zsim(:,1)>norminv(p1) & zsim(:,2)<=norminv(p2);
C3=zsim(:,1)>norminv(p1)  & zsim(:,2)>norminv(p2);

zsimInd=nan(size(zsim,1),1);
zsimInd(C1)=1;zsimInd(C2)=2;zsimInd(C3)=3;
