load 'Data/Ex1_Data.mat' zrefGaus1 zrefGaus2

load 'Results/Charge2.mat'
%%
Zref=PGS([zrefGaus1,zrefGaus2],1);
%ZUC=PGS(ZSimUC,nbsim);
ZGD1=PGS(ZSimSSTBM_GD2,nbsim);
%ZGD2=PGS(ZSimSSTBM_GD2,nbsim);
ZM1=PGS(ZSimSSTBM_M2,nbsim);
%ZM2=PGS(ZSimSSTBM_M2,nbsim);
ZONE1=PGS(ZSimSSTBM_ONE2,nbsim);
%ZONE2=PGS(ZSimSSTBM_ONE2,nbsim);

meanZUC=0;meanZGD1=0;%meanZGD2=0;
meanZM1=0;%meanZM2=0;
meanZONE1=0;%meanZONE2=0;
%ZindUC=nan(nbsim,1);
%ZindGD2=nan(nbsim,1);
ZindGD1=nan(nbsim,1);
%ZindM2=nan(nbsim,1);
ZindM1=nan(nbsim,1);
%ZindONE2=nan(nbsim,1);
ZindONE1=nan(nbsim,1);
for i=1:nbsim
    %ZindUC(i)=sum((ZUC(:,i)==Zref))/nx/ny;
    ZindGD1(i)=sum((ZGD1(:,i)==Zref))/nx/ny;
    %ZindGD2(i)=sum((ZGD2(:,i)==Zref))/nx/ny;
    ZindM1(i)=sum((ZM1(:,i)==Zref))/nx/ny;
    %ZindM2(i)=sum((ZM2(:,i)==Zref))/nx/ny;
    ZindONE1(i)=sum((ZONE1(:,i)==Zref))/nx/ny;
    %ZindONE2(i)=sum((ZONE2(:,i)==Zref))/nx/ny;
%meanZUC=meanZUC+(ZUC(:,i)==Zref)/nbsim;
meanZGD1=meanZGD1+(ZGD1(:,i)==Zref)/nbsim;
%meanZGD2=meanZ2+(ZGD2(:,i)==Zref)/nbsim;
meanZM1=meanZM1+(ZM1(:,i)==Zref)/nbsim;
%meanZM2=meanZM2+(ZM2(:,i)==Zref)/nbsim;
meanZONE1=meanZONE1+(ZONE1(:,i)==Zref)/nbsim;
%meanZONE2=meanZONE2+(ZONE2(:,i)==Zref)/nbsim;
end

% figure(2); 
% imagesc(reshape(meanZUC,[nx ny])')
% set(gca,'YDir','normal')
% colormap('summer')
% colorbar()

figure(3); 
imagesc(reshape(meanZGD1,[nx ny])')
set(gca,'YDir','normal')
colormap('summer')
colorbar()

%%
mean([ meanZGD1  meanZM1  meanZONE1 ])
std([ meanZGD1  meanZM1  meanZONE1 ])

%%

[ mean(ZGD1==1,'all') mean(ZGD1==2,'all') mean(ZGD1==3,'all') mean(ZGD1==4,'all') mean(ZGD1==5,'all')]
