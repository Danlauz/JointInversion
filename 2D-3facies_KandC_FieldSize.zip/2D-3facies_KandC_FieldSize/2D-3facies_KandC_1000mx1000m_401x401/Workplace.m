for nHD=[24]
    for nodata=[1]
        for Nphases=[250]
            for ndiv=[1]
                for nswitch=[200]

                    nbHD=nHD-12;
                    Reference_3facies(nbHD,nodata)

                    clearvars -except nbHD nodata nHD Nphases nswitch ndiv

                    load('3facies.mat')
                    x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid

                    %Unconditional simulation obtained by spectral simulations (STBM)
                    nl=1000;
                    [ZSimU_C]=STBM(x0,model_C,c_C,nbsim,[],[],nl,seed);
                    ZSimUInd_C=nan(nx*ny*nz,nbsim);
                    for i=1:nbsim
                        ZSimUInd_C(:,i)=PGS_transform(ZSimU_C(:,:,i),ConstantData);
                    end
                    [ZSimU_K]=STBM(x0,model_K,c_K,nbsim,[],[],nl,seed+562);

                    %Calibrated realizations obtained by S-STBM - K constant - C variable
                    tic
                    MaxIter=5;
                    [ZSim_HD,errSSTBM_HD,iterSSTBM_HD]=S_STBM_HD(x0,model_C,c_C,nbsim,nl,MaxIter,OFmin,seed+865,ConstantDataHD);
                    t_HD=toc/12/60;
                    %%
                    LocHD_C=ConstantDataHD{3};
                    HD_C=ZSim_HD(LocHD_C,:,:);

                    clearvars -except  LocHD_C HD_C ZSim_HD errSSTBM_HD iterSSTBM_HD ZSimU_C ZSimUInd_C ZSimU_K nbHD nodata nHD Nphases nswitch ndiv

                    %Load Simulations parameters
                    load '3facies.mat' model_C model_K c_C c_K nbsim nx ny nz nbiter seed OFmin  HD_K  LocHD_K ConstantData ConstantDataHD zref_C zref_K ZrefInd
                    x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
                    saveData='true'; %Save the data

                    %For fast computation, the number of simulations is fixed to 6 and the number
                    %of iteration is fixed to 500. Parfor loop are removed in each algorithm
                    %(SSTBM,GD,ISR,PA,FFTMASA,STBM) but can be easily added.

                    %Unconditional simulation obtained by spectral simulations (STBM)
                    nl=1000;
                    [ZSimU_HD_C]=STBM_C(x0,model_C,c_C,nbsim,HD_C,LocHD_C,nl,seed+96635);

                    ZSimUInd_HD_C=nan(nx*ny*nz,nbsim);
                    for i=1:nbsim
                        ZSimUInd_HD_C(:,i)=PGS_transform(ZSimU_HD_C(:,:,i),ConstantData);
                    end


                    if isempty(LocHD_K)
                        HD_Ki{1}=[];HD_Ki{2}=[];HD_Ki{3}=[];
                        LocHD_Ki{1}=[];LocHD_Ki{2}=[];LocHD_Ki{3}=[];
                    else
                        HD_Ki{1}=HD_K(ZSimUInd_HD_C(LocHD_K,1)==1,1);
                        HD_Ki{2}=HD_K(ZSimUInd_HD_C(LocHD_K,1)==2,2);
                        HD_Ki{3}=HD_K(ZSimUInd_HD_C(LocHD_K,1)==3,3);

                        LocHD_Ki{1}=LocHD_K(ZSimUInd_HD_C(LocHD_K,1)==1);
                        LocHD_Ki{2}=LocHD_K(ZSimUInd_HD_C(LocHD_K,1)==2);
                        LocHD_Ki{3}=LocHD_K(ZSimUInd_HD_C(LocHD_K,1)==3);
                    end
                    ZSimU_HD_K=STBM_K(x0,model_K,c_K,nbsim,HD_Ki,LocHD_Ki,nl,seed+8747);

                    ErrInit_UHD=nan(nbsim,1);ErrInit_U=nan(nbsim,1);
                    for i=1:nbsim
                        ErrInit_UHD(i)=ObjFunc(ZSimU_HD_C(:,:,i),ZSimU_HD_K(:,:,i),ConstantData);
                        ErrInit_U(i)=ObjFunc(ZSimU_C(:,:,i),ZSimU_K(:,:,i),ConstantData);
                    end

                    HD{1}=reshape(HD_C(:,1,:),length(LocHD_C),nbsim);LocHD{1}=LocHD_C;
                    HD{2}=reshape(HD_C(:,2,:),length(LocHD_C),nbsim);LocHD{2}=LocHD_C;
                    HD{3}=repmat(HD_Ki{1},1,nbsim);LocHD{3}=LocHD_Ki{1};
                    HD{4}=repmat(HD_Ki{2},1,nbsim);LocHD{4}=LocHD_Ki{2};
                    HD{5}=repmat(HD_Ki{3},1,nbsim);LocHD{5}=LocHD_Ki{3};

                    %% Calibrated realizations obtained by S-STBM - K variable - C variable

                    tic
                    MaxIter=2;nbIter=100;nl=Nphases*nbIter;
                    [ZSim,errSSTBM,iter]=S_STBM_nphase_GD(x0,[model_C;model_K],[c_C;c_K],nbsim,HD,LocHD,nl,MaxIter,seed+254,ConstantData,Nphases,nbIter,nswitch,ndiv);
                    t=toc/60
                    ZSimInd=nan(nx*ny*nz,nbsim);
                    for i=1:nbsim
                        ZSimInd(:,i)=PGS_transform(ZSim(:,:,i),ConstantData);
                    end
                    figure(85)
                    semilogy(errSSTBM/mean(ErrInit_UHD),'k'); hold on; semilogy(mean(errSSTBM'/mean(ErrInit_UHD)),'r')
                    [mean(ErrInit_U) mean(ErrInit_UHD) mean(errSSTBM(end,:))]


                    %%
                    %Save results in a folder
                    if saveData=='true'
                        save(['Transient_nbHD' num2str(nHD) '_puitHD' num2str(nodata) '_Nphases' num2str(Nphases) '_ndiv' num2str(ndiv) '_nswitch' num2str(nswitch) '.mat']);
                    end
                end
            end
        end
    end
end