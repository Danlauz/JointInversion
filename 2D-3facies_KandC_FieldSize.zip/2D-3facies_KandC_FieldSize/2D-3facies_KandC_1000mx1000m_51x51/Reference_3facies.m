function []=Reference_3facies(nbHD,nodata)

mrstModule add ad-props  ad-core ad-blackoil

%variogram model from varioFFT2D_dl.m and covardm.m
model_C=[ 6 30 5 5 0 0 0;
          2 10 5 5 0 0 0];
c_C=[1;1];

model_K=[ 2 12.5 12.5 12.5 0 0 0;...
          2 12.5 12.5 12.5 0 0 0;...
          2 12.5 12.5 12.5 0 0 0];
c_K=[0.2; 0.2; 0.2];

nbsim=1; %One reference field
nx=51; ny=51; nz=1; %dimension of the field (fix nz=1)
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid


%Piezometer location
x0Ref=[ 29 26; 36 26; 23 26; 16 26;...
        26 29; 26 36; 26 23; 26 16;...
        41 41; 41 11; 11 41; 11 11];     
dist=sqrt(sum((x0Ref-[26 26]).^2,2));
invdist=1./dist;
suminvdist=sum(invdist);
%Index in grid
LocData=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%Source Localisation and Index
x0Ref=[ 26 26];
LocInj=nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%

%Gaussien field reference
p1=0.2; p2=0.4;

zref_C1=STBM(x0,model_C(1,:),c_C(1),nbsim,-0.2,LocInj,2000,78632);
zref_C2=STBM(x0,model_C(2,:),c_C(2),nbsim,[],[],2000,4784);
zref_C=[zref_C1,zref_C2]; 


zref_K1=STBM(x0,model_K(1,:),c_K(1),nbsim,[],[],2000,85985);
zref_K2=STBM(x0,model_K(2,:),c_K(2),nbsim,[],[],2000,12451);
zref_K3=STBM(x0,model_K(3,:),c_K(3),nbsim,[],[],2000,3545896);
zref_K=[zref_K1,zref_K2,zref_K3];

if nbHD>=1 && nodata==1
    p=haltonset(2);
    x0HD=[ceil(p(14584:14584+nbHD-1,1)*nx),ceil(p(14584:14584+nbHD-1,2)*ny)];
    LocDataHD=unique([LocData; nx*(x0HD(:,2)-1)+x0HD(:,1)]);
    HD_K=zref_K(LocData,:); LocHD_K=LocData;
elseif nbHD==0 && nodata==1
    LocDataHD=LocData;
    HD_K=zref_K(LocData,:); LocHD_K=LocData;
elseif nbHD>=1 && nodata==0
    p=haltonset(2);
    x0HD=[ceil(p(14584:14584+nbHD-1,1)*nx),ceil(p(14584:14584+nbHD-1,2)*ny)];
    LocDataHD=unique(nx*(x0HD(:,2)-1)+x0HD(:,1));
    HD_K=[]; LocHD_K=[];
elseif nbHD==0 && nodata==0
    LocDataHD=[];HD_K=[]; LocHD_K=[];
end
HD_C=[]; LocHD_C=LocDataHD;
ZrefInd=PGS_visuel_3facies(zref_C,nx,ny,LocDataHD,x0,1555,p1,p2);
%% Inequality constraints 

NewDepth=nan(4,length(LocHD_C));
%C1
C1=zref_C1(LocHD_C)<=norminv(p1);
NewDepth(1,C1)=-inf;
NewDepth(2,C1)=norminv(p1);
NewDepth(3,C1)=-inf;
NewDepth(4,C1)=inf;
%C2
C2=zref_C1(LocHD_C)>norminv(p1) & zref_C2(LocHD_C)<=norminv(p2);
NewDepth(1,C2)=norminv(p1);
NewDepth(2,C2)=inf;
NewDepth(3,C2)=-inf;
NewDepth(4,C2)=norminv(p2);
%C3
C3=zref_C1(LocHD_C)>norminv(p1) & zref_C2(LocHD_C)>norminv(p2);
NewDepth(1,C3)=norminv(p1);
NewDepth(2,C3)=inf;
NewDepth(3,C3)=norminv(p2);
NewDepth(4,C3)=inf;


lb=NewDepth([1 3],:)';
ub=NewDepth([2 4],:)';

ConstantDataHD{1}=lb;
ConstantDataHD{2}=ub;
ConstantDataHD{3}=LocDataHD;
%% Grid, petrophysics, and fluid objects

% The grid and rock model
G    = computeGeometry(cartGrid([nx ny 1],[1000 1000 1]));
rock = makeRock(G, 100*darcy, 0.3);
C1=zref_C1<=norminv(p1);
C2=zref_C1>norminv(p1)  & zref_C2<=norminv(p2);
C3=zref_C1>norminv(p1) & zref_C2> norminv(p2);

rock.perm=zeros(size(zref_K1));
rock.perm(C1)=10.^(zref_K1(C1)+log10(0.2*darcy));  % 0.005 silty sand
rock.perm(C2)=10.^(zref_K2(C2)+log10(30*darcy));    % 0.5 clear sand
rock.perm(C3)=10.^(zref_K3(C3)+log10(150*darcy));    % 50 clear sand
C=[C1,C2,C3];

% Fluid properties
fluid = initSimpleADIFluid('phases','W',           ... % Fluid phase: water
                           'mu',  1*centi*poise,   ... % Viscosity
                           'rho', 1000,            ... % Surface density [kg/m^3]
                           'c',   4.4e-10,      ... % Fluid compressibility
                           'cR',  1.0062e-08       ... % Rock compressibility
                           );

% Make Reservoir Model
gravity reset on
wModel = WaterModel(G, rock, fluid,'gravity',[0 0 -norm(gravity)]);
% Prepare the model for simulation.
wModel = wModel.validateModel();
% Drive mechansims and schedule

% Well: at the midpoint of the south edge
wc = sub2ind(G.cartDims, LocInj);
W = addWell([], G, rock,  wc,     ...
        'Type', 'rate', 'Val', -25*meter^3/hour, ...
        'Radius', 0.1, 'Name', 'P1','Comp_i',1,'sign',-1);

% Boundary conditions: fixed pressure at E-W sides and no-flow elsewhere
bc  = pside([], G, 'EAST', 9.80638*1000*0, 'sat', 1);
bc  = pside(bc, G, 'WEST', 9.80638*1000*5, 'sat', 1);

% Schedule: describing time intervals and corresponding drive mechanisms
schedule = simpleSchedule(diff(linspace(0,7*day,7)), 'bc', bc, 'W', W);
schedule.step.val=10.^[2 3 4 5 6 7]-[0 10.^[2 3 4 5 6]];
TStep= [1 2 3 4 5 6];

% Reservoir state
state = initResSol(G, 0.0,1);
state.wellSol  = initWellSolAD([], wModel, state);      % No well initially

% Vertical equilibrium
verbose = false;
nonlinear = NonLinearSolver();
stateInit = nonlinear.solveTimestep(state, 10000*day, wModel, 'bc', bc);

% Run simulations
% Simulation pressure
tic
[~, states] = simulateScheduleAD(stateInit, wModel, schedule);
t=toc
%%
contligne=[-0.5,-0.5,-0.25,-0.250,0,0.5,0.5,1,1,2,2,3,3,4,4,5,5];
figure(100)
x = linspace(1,nx,ny);
y = linspace(1,nx,ny);
[X,Y] = meshgrid(x,y);
Z = reshape(stateInit.pressure*0.000101974,[nx,ny])';

imagesc(reshape(stateInit.pressure*0.000101974,[nx,ny])');
hold on
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
hold on
[c1,h]=contour(X,Y,Z,contligne,'--k','ShowText','on');
h.LevelList=round(h.LevelList,2);
clabel(c1,h)
colormap(jet)
colorbar()
caxis([-2 5])
set(gca,'YDir','normal')
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
%title('Reference pressure head field (m)')

for i=1:numel(states)
    figure(100+i)
    x = linspace(1,nx,ny);
    y = linspace(1,nx,ny);
    [X,Y] = meshgrid(x,y);
    Z = reshape(states{i}.pressure*0.000101974,[nx,ny])';

    imagesc(reshape(states{i}.pressure*0.000101974,[nx,ny])');
    hold on
    plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
    hold on
    plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
    hold on
    [c1,h]=contour(X,Y,Z,contligne,'--k','ShowText','on');
    h.LevelList=round(h.LevelList,2);
    clabel(c1,h)
    colormap(jet)
    colorbar()
    caxis([-2 5])
    set(gca,'YDir','normal')
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
    %title('Reference pressure head field (m)')
end

figure(199)
imagesc(reshape(zref_C(:,1),[nx,ny])');
colormap(jet)
colorbar()
caxis([-3 3])
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
set(gca,'YDir','normal')

figure(200)
imagesc(reshape(zref_C(:,2),[nx,ny])');
colormap(jet)
colorbar()
caxis([-3 3])
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
set(gca,'YDir','normal')

figure(201)

imagesc(reshape(log10(rock.perm)+7,[nx,ny])');
hold on
plot(x0(LocInj,1),x0(LocInj,2),'ok','markersize',8,'LineWidth',2)
hold on
plot(x0(LocData,1),x0(LocData,2),'xk','markersize',8,'LineWidth',2)
colormap(jet)
colorbar()
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)
set(gca,'YDir','normal')
%%
figure(6)
Rabattement=nan(length(states),length(LocData));
for k1=1:length(states)
    for k2=1:length(LocData)
        Rabattement(k1,k2)=states{k1}.pressure(LocData(k2))*0.000101974;
    end
end

RInit_sim=nan(1,length(LocData));
for k1=1:length(LocData)
    RInit_sim(k1)=stateInit.pressure(LocData(k1))*0.000101974;
end
Rabattement=[RInit_sim; Rabattement];

for i=1:length(LocData)
    if i==6
        plot([0 TStep],Rabattement(:,i),'r')
    else
        plot([0 TStep],Rabattement(:,i),'k')
    end
    hold on
end


ConstantData{1}=G;
ConstantData{2}=fluid;
ConstantData{3}=W;
ConstantData{4}=bc;
ConstantData{5}=rock;
ConstantData{6}=LocData;
ConstantData{7}=Rabattement;
ConstantData{8}=p1;
ConstantData{9}=p2;
ConstantData{10}=invdist;
%%
nbsim=100; nbiter=200; seed=185632; OFmin=0;

save 3facies.mat model_C model_K c_C c_K nbsim nx ny nz nbiter seed OFmin HD_C HD_K LocHD_C LocHD_K ConstantData ConstantDataHD zref_C ZrefInd zref_K