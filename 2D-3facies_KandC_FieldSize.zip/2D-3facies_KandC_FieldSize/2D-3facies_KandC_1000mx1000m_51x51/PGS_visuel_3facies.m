function [zsimInd]=PGS_visuel_3facies(zsim,nx,ny,LocData,x0,sim,p1,p2)

C1=zsim(:,1)<=norminv(p1);
C2=zsim(:,1)>norminv(p1) & zsim(:,2)<=norminv(p2);
C3=zsim(:,1)>norminv(p1)  & zsim(:,2)>norminv(p2);

zsimInd=nan(size(zsim,1),1);
zsimInd(C1)=0.5;zsimInd(C2)=2;zsimInd(C3)=3.5;

figure(sim)
imagesc(reshape(zsimInd,[nx ny])')
hold on
plot(x0(LocData,1),x0(LocData,2),'ok','markersize',8,'LineWidth',2)
hold on
plot(x0(1301,1),x0(1301,2),'ok','markersize',8,'LineWidth',2)
colormap(flip([1 1 1 ; 0.5 0.5 0.5; 0 0 0]))
set(gca,'YDir','normal')
colormap('summer')
colorbar('Ticks',[1,2,3],'TickLabels',[1,2,3])
xticklabels = 0:100:1000;
xticks = linspace(1, 101, numel(xticklabels));
set(gca, 'XTick', xticks, 'XTickLabel', xticklabels)
yticklabels = 0:100:1000;
yticks = linspace(1, 101, numel(yticklabels));
set(gca, 'YTick', yticks, 'YTickLabel', yticklabels)