%% Objective function 
for i=1:100
    semilogy([0:3:300],[errSSTBMAll(1,i); errSSTBMAll(:,i)/mean(ErrInit_UHDAll)],'color',[0.9 0.9 0.9]);
    hold on;
end
semilogy([0:3:300],[1 mean(errSSTBMAll'/mean(ErrInit_UHDAll))],'k','LineWidth',2)
grid on

semilogy([0:3:300],[1 quantile(errSSTBMAll'/mean(ErrInit_UHDAll),0.9)],'--k','LineWidth',1.5)
grid on

semilogy([0:3:300],[1 quantile(errSSTBMAll'/mean(ErrInit_UHDAll),0.1)],'--k','LineWidth',1.5)
grid on

ylabel('Normalized objective function')
xlabel('Number of calls to the flow simulator')

ylim([0.09 1.2])

%% Table 2 Data
[ mean(ErrInit_UAll) mean(ErrInit_UHDAll) mean(errSSTBMAll(end,:)) std(errSSTBMAll(end,:))]

%% Table 3 Data

ZindRef=PGS_transform(zref_C,ConstantData);
for i=1:100
    ZindSim=PGS_transform(ZSimAll(:,1:2,i),ConstantData);
    PCf(i)=sum(ZindRef==ZindSim)/size(ZSimAll,1);
    ZindSim=PGS_transform(ZSimU_HD_CAll(:,:,i),ConstantData);
    PCi(i)=sum(ZindRef==ZindSim)/size(ZSimAll,1);
end

KRef=log10(Permeability(zref_C,zref_K,ConstantData));
for i=1:100
    KSim=log10(Permeability(ZSimAll(:,1:2,i),ZSimAll(:,3:5,i),ConstantData));
    Kf(:,i)=corr(KRef,KSim);
    KSim=log10(Permeability(ZSimU_HD_CAll(:,:,i),ZSimU_HD_KAll(:,:,i),ConstantData));
    Ki(i)=corr(KRef,KSim);
end


[mean(ErrInit_UHDAll) mean(errSSTBMAll(end,:)) std(errSSTBMAll(end,:))]
[ mean(PCi) mean(PCf)]
[mean(Ki) mean(Kf) ]