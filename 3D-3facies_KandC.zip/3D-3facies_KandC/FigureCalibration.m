
ind=1;
switch ind
    case 1
        sim=ind;
        zsim=[zref_C zref_K];
    case 2
        sim=ind;
        zsim=ZSimAll(:,:,7);
    case 3
        sim=ind;
        zsim=ZSimAll(:,:,12);
end

%Source Localisation and Index
nx=101;ny=101;nz=11;
x0Ref=[ 51*ones(11,1) 51*ones(11,1) (1:11)' ];
LocInj=ny*nx*(x0Ref(:,3)-1)+nx*(x0Ref(:,2)-1)+x0Ref(:,1);
p1=0.20; p2=0.40;
prob=[p1 p2];
dx=2000;dy=2000;dz=10;dp=0;
x0=grille3(1,nx,1,1,ny,1,1,nz,1);

% Plurigaussian simulation
ZrefInd=PGS_visuel_3facies(zsim(:,1:2),nx,ny,nz,LocHD{1},LocInj,x0,ind,prob);
%%
% Flow simulator 
[error,R_sim,states,Rt,stateInit,rock]=ObjFunc(zsim(:,1:2),zsim(:,3:5),ConstantData);

%% Hydraulic conductivity field
figure(5)
[X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
V=flip(reshape(log10(rock.perm(:,1))+7,[nx ny nz]));
xslice = [0 2000];   
yslice = [0 1010 2000];
zslice = [0 5];
h=slice(X,Y,Z,V,yslice,xslice,zslice);
set(h,'edgecolor','none')
colorbar()
set(gca,'YDir','normal')
colormap('jet')
pbaspect([1 1 0.25])
for j=1:12
    hold on
    plot3(x0(LocHD{1}(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocHD{1}(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocHD{1}(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
end
hold on
plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
view([-90 -25 85])

caxis([-7.6 -1.8])

%% Drawdowm 

figure(158)
[X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
V=flip(reshape(stateInit.pressure*0.000101974 ,[nx,ny,nz]));
colorbar(); caxis([-2 10])
set(gca,'YDir','normal')
colormap('jet')
pbaspect([1 1 0.25])
for j=1:12
    hold on
    plot3(x0(LocHD{1}(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocHD{1}(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocHD{1}(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
end
hold on
plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
view([-90 -25 85])
for k=[-2 -1 -0.5 0 0.5 1 2 3 4 5 6 7 8 9 9.9]
    hold on
    isosurface(X,Y,Z,V,k);
end

for i=[1 3 6]
    figure(100+i)
    [X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
    V=flip(reshape(states{i}.pressure*0.000101974 ,[nx,ny,nz]));
    colorbar(); caxis([-2 10])
    set(gca,'YDir','normal')
    colormap('jet')
    pbaspect([1 1 0.25])
    for j=1:12
        hold on
        plot3(x0(LocHD{1}(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocHD{1}(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocHD{1}(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
    end
    hold on
    plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
    view([-90 -25 85])
    for k=[-2 -1 -0.5 0 0.5 1 2 3 4 5 6 7 8 9 9.9]
        hold on
        isosurface(X,Y,Z,V,k);
    end
end