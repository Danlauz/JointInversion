function [zsimInd]=PGS_visuel_3facies(zsim,nx,ny,nz,LocData,LocInj,x0,sim,p)

p1=p(1);p2=p(2);

C1=zsim(:,1)<=norminv(p1);
C2=zsim(:,1)>norminv(p1) & zsim(:,2)<=norminv(p2) ;
C3=zsim(:,1)>norminv(p1) & zsim(:,2)>norminv(p2) ;


zsimInd=nan(size(zsim,1),1);
zsimInd(C1)=1;zsimInd(C2)=2;zsimInd(C3)=3;

figure(sim)
[X,Y,Z] = meshgrid(0:2000/(ny-1):2000,0:2000/(nx-1):2000,0:10/(nz-1):10);
V=flip(reshape(zsimInd,[nx ny nz]));
xslice = [0 2000];   
yslice = [0 1025 2000];
zslice = [0 5];
h=slice(X,Y,Z,V,yslice,xslice,zslice);
set(h,'edgecolor','none')
colormap(flip([1 1 1 ; 0.5 0.5 0.5; 0.2 0.2 0.2]))
colorbar()
set(gca,'YDir','normal')
colormap('summer')
colorbar('Ticks',[1.3333,2,2.666666],'TickLabels',[1,2,3])
pbaspect([1 1 0.25])
for j=1:12
    hold on
    plot3(x0(LocData(1+(j-1)*11:j*11),2)*2000/(ny-1),x0(LocData(1+(j-1)*11:j*11),1)*2000/(nx-1),x0(LocData(1+(j-1)*11:j*11),3)*10/(nz-1),'k-','LineWidth',2)
end
hold on
plot3(x0(LocInj,2)*2000/(ny-1),x0(LocInj,1)*2000/(nx-1),x0(LocInj,3)*10/(nz-1),'r-','LineWidth',2)
view([-90 -25 85])