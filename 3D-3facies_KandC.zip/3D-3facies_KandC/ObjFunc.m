function [error,R_sim,states,Rt,stateInit,rock]=ObjFunc(zsim_C,zsim_K,ConstantData,time)

if nargin==3
    time=1;
end

G=ConstantData{1};
fluid=ConstantData{2};
W=ConstantData{3};
bc=ConstantData{4};
rock=ConstantData{5};
LocData=ConstantData{6};
R_ref=ConstantData{7};
p1=ConstantData{8};
p2=ConstantData{9};

%%% Initialization
C1=zsim_C(:,1)<=norminv(p1);
C2=zsim_C(:,1)>norminv(p1)  & zsim_C(:,2)<=norminv(p2);
C3=zsim_C(:,1)>norminv(p1)  & zsim_C(:,2)> norminv(p2);

rock.perm=zeros(size(zsim_K(:,1)));
rock.perm(C1)=10.^(zsim_K(C1,1)+log10(0.07*darcy));  % 0.005 silty sand
rock.perm(C2)=10.^(zsim_K(C2,2)+log10(1.5*darcy));    % 0.5 clear sand
rock.perm(C3)=10.^(zsim_K(C3,3)+log10(20*darcy));    % 50 clear sand

% Make Reservoir Model
gravity reset off
wModel = WaterModel(G, rock, fluid,'gravity',[0 0 0]);
% Prepare the model for simulation.
wModel = wModel.validateModel();
% Drive mechansims and schedule

% Schedule: describing time intervals and corresponding drive mechanisms
schedule = simpleSchedule(diff(linspace(0,7*day,7)), 'bc', bc, 'W', W);
schedule.step.val=10.^[ 3 4 5 6 7 9]-[0 10.^[ 3 4 5 6 7]];

% Reservoir state
state = initResSol(G,  0, 1.0);
state.wellSol  = initWellSolAD([], wModel, state);      % No well initially

% Vertical equilibrium
verbose = false;
nonlinear = NonLinearSolver();
stateInit = nonlinear.solveTimestep(state, 10000*day, wModel, 'bc', bc);

% Run simulations
% Simulation pressure
[~, states] = simulateScheduleAD(stateInit, wModel, schedule);

R_sim=nan(length(states),length(LocData));
for k1=1:length(states)
    for k2=1:length(LocData)
        R_sim(k1,k2)=states{k1}.pressure(LocData(k2))*0.000101974;
    end
end

RInit_sim=nan(1,length(LocData));
for k1=1:length(LocData)
    RInit_sim(k1)=stateInit.pressure(LocData(k1))*0.000101974;
end
R_sim=[RInit_sim; R_sim];

Rt=states{time}.pressure*0.000101974;

%error=sqrt(mean(((R_ref(3:2:end,2:end)-R_sim(3:2:end,2:end)).^2),'all'));
error=sqrt(mean(((R_ref(:,1:end)-R_sim(:,1:end)).^2),'all'));