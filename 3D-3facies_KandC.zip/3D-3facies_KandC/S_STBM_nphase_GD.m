function [Zsim,Err,Iter]=S_STBM_nphase_GD(x0,model,c,nbsim,HD,LocHD,nl,MaxIter,seed,ConstantData,nphases,nbIter,nswitch,ndiv)
% Generated calibrated Gaussian random field using the sequential spectral turning band method
    %input:
    %x0  -- Grid (nbpoint x dim)
    %model -- covariance model
    %c -- sill (one for each model)
    %nbsim -- number of simulation
    %zHD --   values of hard data  (nbHDx1)
    %LocHD -- localization of hard data (nbHDx1)
    %nl -- number of lines calibrated
    %MaxIter -- maximum number of iteration for the optimizer
    %OFmin -- minimum objective function value to reach
    %type -- Objective function to evaluate
    %seed -- for reproductability
    
    %return:
    %Z  -- Calibrated Random Gaussian field
    %Err  -- Objective function value
    %Delta  -- Mean pixel perturbation
    %Phi  -- vector of optimized phase
    %Iter  -- Number of iteration performed
    
    % Authors : Dany Lauzon
    
%1- Spectral density computation for PGS and Gaussian conductivity fields
[F1init,sinit,rot,cx]=DensSpec1Ddl(x0,model,c);


%2-covariance matrix for the post-conditioning (PGS and Gaussian conductivity fields)
k=cell(size(F1init,2),1);
ki=cell(size(F1init,2),1);
k0=cell(size(F1init,2),1);
for i=1:size(F1init,2)
    k{i}=covardm(x0(LocHD{i},:),x0(LocHD{i},:),model(i,:),c(i));
    ki{i}=inv(k{i});
    k0{i}=covardm(x0(LocHD{i},:),x0,model(i,:),c(i));
end

%nbsim simuation
parfor j=1:nbsim
    j
    %For reproductability
    rng('default')
    rng(2*j+seed);
    %Initialization
    F1=F1init; s=sinit;
    z1=cell(size(F1init,2),1);
    zsim      =zeros(size(x0,1),size(F1,2));
    zsimBest  =zeros(size(x0,1),size(F1,2));
    err=nan(nbIter,1); errNow=1000;
    Nphases=nphases;
    
    
    %Optimization on phase U
    i=0;itt=0;ii=Nphases;
    while i<nbIter
        i=i+1

        for k=1:size(F1,2) %Done for each covariance model.
            %3-Sampled random frequencies
            p=rand(Nphases,1);
            ul1=interp1(F1{k},s{k},p); % interpolate ul from p and cum
            %4-Random vector
            z=VanCorput(Nphases);    % Van Corput sequence
            %5- Frequency vector
            z1{k}=z.*ul1;
        end

        Y=randn(size(z1,1),Nphases,2);
        %6- Calibration process on the phase U
        options=optimset('MaxIter',MaxIter,'TolX',10^-8,'Display','off');
        func = @(t) OptErr(t,Y,ii,x0,zsim,c,cx,rot,z1,HD,LocHD,ki,k0,ConstantData,j,Nphases);
        X=rand(1);X=[X-0.5 X+0.5];
        [t,errNew] = fminbnd(func, X(1),X(2),options);
        U=normcdf(Y(:,:,1)*cos(2*pi*t)+Y(:,:,2)*sin(2*pi*t));

        %8-Keep the best solution
        if  errNew<=errNow
            errNow=errNew;
            for k=1:size(z1,1)
                zsim(:,k)=zsim(:,k)*sqrt((ii-Nphases)/ii)+sqrt(Nphases/ii)*sum(sqrt(2/Nphases)*sqrt(c(k))*cos((cx{k}*rot{k}')*z1{k}'+ ones(size(cx{k},1),1)*2*pi*U(k,:) ),2);
                if ~isempty(LocHD{k})
                    z= postcond( [x0(LocHD{k},:) ,HD{k}(:,j)] , [x0(LocHD{k},:) , zsim(LocHD{k},k)], [x0 ,zsim(:,k)] , 1 , ki{k} ,k0{k} );
                    zsimBest(:,k)=z(:,end);
                else
                    zsimBest(:,k)=zsim(:,k);
                end
            end
            itt=itt+1;
            ii=ii+Nphases;
            if mod(itt,nswitch)==0
                Nphases=ceil(Nphases/ndiv);
            end
        end

        err(i)=errNow; 
    end

    %9- Return Z and other parameters
    Err(:,j)=err;
    Zsim(:,:,j)=zsimBest;
    Iter(j)=itt;
end

function [error]=OptErr(t,Y,ii,x0,zsim,c,cx,rot,z1,HD,LocHD,ki,k0,ConstantData,j,Nphases)

U=normcdf(Y(:,:,1)*cos(2*pi*t)+Y(:,:,2)*sin(2*pi*t));
for k=1:size(z1,1) %Done for each covariance model.
    zsim(:,k)=zsim(:,k)*sqrt((ii-Nphases)/ii)+sqrt(Nphases/ii)*sum(sqrt(2/Nphases)*sqrt(c(k))*cos((cx{k}*rot{k}')*z1{k}'+ ones(size(cx{k},1),1)*2*pi*U(k,:) ),2);
    % Post-Cond
    if ~isempty(LocHD{k})
        z= postcond( [x0(LocHD{k},:) ,HD{k}(:,j)] , [x0(LocHD{k},:) , zsim(LocHD{k},k)], [x0 ,zsim(:,k)] , 1 , ki{k} ,k0{k} );
        zsim(:,k)=z(:,end);
    end
end

zsim_C=zsim(:,1:2);
zsim_K=zsim(:,3:end);

error=ObjFunc(zsim_C,zsim_K,ConstantData);
