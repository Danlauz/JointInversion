function []=Reference_3facies(nbHD,nodata)

mrstModule add ad-props  ad-core ad-blackoil

%variogram model from varioFFT2D_dl.m and covardm.m
% model_C1={[10 200 5 ; 0 0 0.2]};
% model_C2={[10 200 5 ; 0 0 0.2]};
% ax=5;ay=0;az=3;beta=-0.80;

model_C=[ 3 10/sqrt(3) 30/sqrt(3) 8/sqrt(3) 0 0 0;...
          6 20 80 8 0 0 0];
c_C=[1; 1];

model_K=[ 2 25/3 25/3 4/3 0 0 0;...
          2 25/3 25/3 4/3 0 0 0;...
          2 25/3 25/3 4/3 0 0 0];
c_K=[0.2; 0.2; 0.2];


nbsim=1; %One reference field
nx=101; ny=101; nz=11; %dimension of the field (fix nz=1)
dx=2000;dy=2000;dz=10;dp=0;

% x0C=grille3(1,nx+ax,1,1,ny+ay,1,1,nz+az,1); %grid
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid

%Piezometer location
x0Ref=[ 57 51 6; 65 51 6; 45 51 6; 33 51 6;...
        51 57 6; 51 65 6; 51 45 6; 51 33 6;...
        81 81 6; 81 21 6; 21 81 6; 21 21 6];     
%Index in grid
LocData=ny*nx*(x0Ref(:,3)-1)+nx*(x0Ref(:,2)-1)+x0Ref(:,1);
%Source Localisation and Index
x0Ref=[ 51*ones(11,1) 51*ones(11,1) (1:11)' ];
LocInj=ny*nx*(x0Ref(:,3)-1)+nx*(x0Ref(:,2)-1)+x0Ref(:,1);

%Gaussien field reference

zref_C1=STBM(x0,model_C(1,:),c_C(1),nbsim,-0.4,LocInj(6),2000,84575);
zref_C2=STBM(x0,model_C(2,:),c_C(2),nbsim,[],[],2000,163);

% zref_C1=STBM_separable(x0C,model_C1,nbsim,2000,4574);
% zref_C2=STBM_separable(x0C,model_C2,nbsim,2000,14251);
% 
% zref_C1shift=reshape(zref_C1,[nx+abs(ax) ny+abs(ay) nz+abs(az)]);zref_C1shift=zref_C1shift(ax+1:nx+ax,ay+1:ny+ay,az+1:nz+az);zref_C1shift=reshape(zref_C1shift,[],1);
% zref_C1=reshape(zref_C1,[nx+abs(ax) ny+abs(ay) nz+abs(az)]);zref_C1=zref_C1(1:nx,1:ny,1:nz);zref_C1=reshape(zref_C1,[],1);
% zref_C2=reshape(zref_C2,[nx+abs(ax) ny+abs(ay) nz+abs(az)]);zref_C2=zref_C2(1:nx,1:ny,1:nz);zref_C2=reshape(zref_C2,[],1);
% zref_C2=beta*zref_C1shift+sqrt(1-beta^2)*zref_C2;

zref_C=[zref_C1,zref_C2]; 



zref_K1=STBM(x0,model_K(1,:),c_K(1),nbsim,[],[],2000,865);
zref_K2=STBM(x0,model_K(2,:),c_K(2),nbsim,[],[],2000,1245);
zref_K3=STBM(x0,model_K(3,:),c_K(3),nbsim,[],[],2000,3596);
zref_K=[zref_K1,zref_K2,zref_K3];

p1=0.20; p2=0.40; 
prob=[p1 p2];

if nbHD>=1 && nodata==1
    x0Ref=[ 57*ones(11,1) 51*ones(11,1) (1:11)'; 65*ones(11,1) 51*ones(11,1) (1:11)'; 45*ones(11,1) 51*ones(11,1) (1:11)'; 33*ones(11,1) 51*ones(11,1) (1:11)';...
            51*ones(11,1) 57*ones(11,1) (1:11)'; 51*ones(11,1) 65*ones(11,1) (1:11)'; 51*ones(11,1) 45*ones(11,1) (1:11)'; 51*ones(11,1) 33*ones(11,1) (1:11)';...
            81*ones(11,1) 81*ones(11,1) (1:11)'; 81*ones(11,1) 21*ones(11,1) (1:11)'; 21*ones(11,1) 81*ones(11,1) (1:11)'; 21*ones(11,1) 21*ones(11,1) (1:11)'];
    p=haltonset(2);
    x0HD=[ceil(p(14584:14584+nbHD-1,1)*nx),ceil(p(14584:14584+nbHD-1,2)*ny)];
    LocDataHD=unique([ny*nx*(x0Ref(:,3)-1)+nx*(x0Ref(:,2)-1)+x0Ref(:,1); nx*(x0HD(:,2)-1)+x0HD(:,1)]);
    HD_K=[]; LocHD_K=[];%HD_K=zref_K(LocDataHD,:); LocHD_K=LocDataHD;
elseif nbHD==0 && nodata==1
    x0Ref=[ 57*ones(11,1) 51*ones(11,1) (1:11)'; 65*ones(11,1) 51*ones(11,1) (1:11)'; 45*ones(11,1) 51*ones(11,1) (1:11)'; 33*ones(11,1) 51*ones(11,1) (1:11)';...
        51*ones(11,1) 57*ones(11,1) (1:11)'; 51*ones(11,1) 65*ones(11,1) (1:11)'; 51*ones(11,1) 45*ones(11,1) (1:11)'; 51*ones(11,1) 33*ones(11,1) (1:11)';...
        81*ones(11,1) 81*ones(11,1) (1:11)'; 81*ones(11,1) 21*ones(11,1) (1:11)'; 21*ones(11,1) 81*ones(11,1) (1:11)'; 21*ones(11,1) 21*ones(11,1) (1:11)'];
    LocDataHD=ny*nx*(x0Ref(:,3)-1)+nx*(x0Ref(:,2)-1)+x0Ref(:,1);
    HD_K=[]; LocHD_K=[];%HD_K=zref_K(LocDataHD,:); LocHD_K=LocDataHD;
elseif nbHD>=1 && nodata==0
    p=haltonset(2);
    x0HD=[ceil(p(14584:14584+nbHD-1,1)*nx),ceil(p(14584:14584+nbHD-1,2)*ny)];
    LocDataHD=unique(nx*(x0HD(:,2)-1)+x0HD(:,1));
    HD_K=[]; LocHD_K=[];
elseif nbHD==0 && nodata==0
    LocDataHD=[];HD_K=[]; LocHD_K=[];
end

HD_C=[]; LocHD_C=LocDataHD;
ZrefInd=PGS_visuel_3facies(zref_C,nx,ny,nz,LocDataHD,LocInj,x0,165,prob);

%% Inequality constraints 

NewDepth=nan(4,length(LocHD_C));
%C1
C1=zref_C1(LocHD_C)<=norminv(p1);
NewDepth(1,C1)=-inf;
NewDepth(2,C1)=norminv(p1);
NewDepth(3,C1)=-inf;
NewDepth(4,C1)=inf;
%C2
C2=zref_C1(LocHD_C)>norminv(p1) & zref_C2(LocHD_C)<=norminv(p2);
NewDepth(1,C2)=norminv(p1);
NewDepth(2,C2)=inf;
NewDepth(3,C2)=-inf;
NewDepth(4,C2)=norminv(p2);
%C3
C3=zref_C1(LocHD_C)>norminv(p1) & zref_C2(LocHD_C)>norminv(p2);
NewDepth(1,C3)=norminv(p1);
NewDepth(2,C3)=inf;
NewDepth(3,C3)=norminv(p2);
NewDepth(4,C3)=inf;


lb=NewDepth([1 3],:)';
ub=NewDepth([2 4],:)';

ConstantDataHD{1}=lb;
ConstantDataHD{2}=ub;
ConstantDataHD{3}=LocDataHD;
%% Grid, petrophysics, and fluid objects

% The grid and rock model
G    = computeGeometry(cartGrid([nx ny nz],[dx dy dz]));
rock = makeRock(G, 1, 0.3);
C1=zref_C1<=norminv(p1);
C2=zref_C1>norminv(p1)  & zref_C2<=norminv(p2);
C3=zref_C1>norminv(p1) & zref_C2> norminv(p2);

rock.perm=zeros(size(zref_K1));
rock.perm(C1)=10.^(zref_K1(C1)+log10(0.07*darcy));  
rock.perm(C2)=10.^(zref_K2(C2)+log10(1.5*darcy));    
rock.perm(C3)=10.^(zref_K3(C3)+log10(20*darcy)); 
C=[C1,C2,C3];

% Fluid properties
fluidbc = initSingleFluid('mu' ,    1*centi*poise     , 'rho', 1000*kilogram/meter^3);
bc  = psideh([], G, 'East', fluidbc,'sat',1);
bc.value=bc.value+9.80638*1000*10;
bc  = psideh(bc, G, 'West', fluidbc,'sat',1);
bc.value=bc.value+9.80638*1000*0;
clear fluidbc

fluid = initSimpleADIFluid('phases','W',           ... % Fluid phase: water
                           'mu',  1*centi*poise,   ... % Viscosity
                           'rho', 1000,            ... % Surface density [kg/m^3]
                           'c',   4.4e-10,      ... % Fluid compressibility
                           'cR',  1.0062e-8       ... % Rock compressibility
                           );


% Make Reservoir Model
gravity reset off
wModel = WaterModel(G, rock, fluid,'gravity',[0 0 0]);
% Prepare the model for simulation.
wModel = wModel.validateModel();
% Drive mechansims and schedule

% Well: at the midpoint of the south edge
radius     = .1;
W = addWell([], G, rock, LocInj, 'Type', 'rate', ...
            'InnerProduct', 'ip_tpf', ...
            'Val', -50*meter^3/hour, 'Radius', radius, 'name', 'P','sign',-1);
W.cstatus(11:end)=0;

% Schedule: describing time intervals and corresponding drive mechanisms
schedule = simpleSchedule(diff(linspace(0,7*day,7)), 'bc', bc, 'W', W);
schedule.step.val=10.^[ 3 4 5 6 7 9]-[0 10.^[ 3 4 5 6 7]];
TStep= [1 2 3 4 5 6];


% Reservoir state
state = initResSol(G,  0, 1.0);
state.wellSol  = initWellSolAD([], wModel, state);      % No well initially

% Vertical equilibrium
verbose = false;
nonlinear = NonLinearSolver();
stateInit = nonlinear.solveTimestep(state, 10000*day, wModel, 'bc', bc);

tic
% Run simulations
% Simulation pressure
[~, states] = simulateScheduleAD(stateInit, wModel, schedule);
t=toc

figure(158)
[X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
V=reshape(stateInit.pressure*0.000101974 ,[nx,ny,nz]);
colorbar(); caxis([0 10])
set(gca,'YDir','normal')
colormap('jet')
pbaspect([1 1 0.25])
for j=1:12
    hold on
    plot3(x0(LocDataHD(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocDataHD(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocDataHD(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
end
hold on
plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
view([-45 -45 80])
for k=[-2 -1 -0.5 0 0.5 1 2 3 4 5 6 7 8 9 9.9]
    hold on
    isosurface(X,Y,Z,V,k);
end

for i=1:numel(states)
    figure(100+i)
    [X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
    V=reshape(states{i}.pressure*0.000101974 ,[nx,ny,nz]);
    colorbar(); caxis([0 10])
    set(gca,'YDir','normal')
    colormap('jet')
    pbaspect([1 1 0.25])
    for j=1:12
        hold on
        plot3(x0(LocDataHD(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocDataHD(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocDataHD(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
    end
    hold on
    plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
    view([-45 -45 80])
    for k=[-2 -1 -0.5 0 0.5 1 2 3 4 5 6 7 8 9]
        hold on
        isosurface(X,Y,Z,V,k);
    end
end

figure(255)
[X,Y,Z] = meshgrid(0:dy/(ny-1):dy,0:dx/(nx-1):dx,0:dz/(nz-1):dz);
V=reshape(log10(rock.perm(:,1))+7,[nx ny nz]);
xslice = [0 2000];   
yslice = [0 1010 2000];
zslice = [0 5];
h=slice(X,Y,Z,V,yslice,xslice,zslice);
set(h,'edgecolor','none')
colorbar()
set(gca,'YDir','normal')
colormap('jet')
pbaspect([1 1 0.25])
for j=1:12
    hold on
    plot3(x0(LocDataHD(1+(j-1)*11:j*11),2)*dy/(ny-1),x0(LocDataHD(1+(j-1)*11:j*11),1)*dx/(nx-1),x0(LocDataHD(1+(j-1)*11:j*11),3)*dz/(nz-1),'k-','LineWidth',2)
end
hold on
plot3(x0(LocInj,2)*dy/(ny-1),x0(LocInj,1)*dx/(nx-1),x0(LocInj,3)*dz/(nz-1),'r-','LineWidth',2)
view([-45 -45 80])

%%

figure(7)
Rabattement=nan(length(states),length(LocData));
for k1=1:length(states)
    for k2=1:length(LocData)
        Rabattement(k1,k2)=states{k1}.pressure(LocData(k2))*0.000101974 ;
    end
end

RInit_sim=nan(1,length(LocData));
for k1=1:length(LocData)
    RInit_sim(k1)=stateInit.pressure(LocData(k1))*0.000101974;
end
Rabattement=[RInit_sim; Rabattement];

for i=1:length(LocData)
    if i==6
        plot([0 TStep],Rabattement(:,i),'r')
    else
        plot([0 TStep],Rabattement(:,i),'k')
    end
    hold on
end


ConstantData{1}=G;
ConstantData{2}=fluid;
ConstantData{3}=W;
ConstantData{4}=bc;
ConstantData{5}=rock;
ConstantData{6}=LocData;
ConstantData{7}=Rabattement;
ConstantData{8}=p1;
ConstantData{9}=p2;
%%
nbsim=12; nbiter=100; seed=185632; OFmin=0;

save 3facies.mat model_C model_K c_C c_K nbsim nx ny nz nbiter seed OFmin HD_C HD_K LocHD_C LocHD_K ConstantData ConstantDataHD zref_C ZrefInd zref_K